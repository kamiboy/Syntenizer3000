//
//  Database.cpp
//  Syntenizer3000
//
//  Created by Camous Moslemi on 01/09/2017.
//
//

#include "Database.hpp"

Database::Database()
{
    genepool.clear();
    strains.clear();
    strainpool.clear();
}
