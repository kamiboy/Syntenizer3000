//
//  Contig.cpp
//  Syntenizer3000
//
//  Created by Camous Moslemi on 13/10/2017.
//

#include "Contig.hpp"

Contig::Contig()
{
    length = -1;
}
