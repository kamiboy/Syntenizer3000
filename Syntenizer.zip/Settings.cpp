//
//  Settings.cpp
//  Syntenizer3000
//
//  Created by Camous Moslemi on 13/06/2017.
//
//

#include "Settings.hpp"
