//
//  Relation.cpp
//  Syntenizer3000
//
//  Created by Camous Moslemi on 23/04/2017.
//
//

#include "Relation.hpp"

Relation::Relation(Gene *g, double s)
{
    gene = g;
    score = s;
};
