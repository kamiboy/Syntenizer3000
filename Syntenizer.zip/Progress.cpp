//
//  Progress.cpp
//  Syntenizer3000
//
//  Created by Camous Moslemi on 15/09/2017.
//
//

#include "Progress.hpp"
